#include "altitudechart.h"

#include <QFont>
#include <QPainter>
#include <QPaintEvent>
#include <QtMath>

AltitudeChart::AltitudeChart(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(300, 280);
}

void AltitudeChart::setData(const QVector<double> &newValues,
                            const QString &title,
                            const QString &unit)
{
    values = newValues;
    chartTitle = title;
    valueUnit = unit;
    update();
}

void AltitudeChart::clearChart()
{
    values.clear();
    update();
}

void AltitudeChart::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.fillRect(rect(), QColor("#F8F9FB"));

    painter.setPen(QColor("#34495B"));
    painter.setFont(QFont(font().family(), 11, QFont::DemiBold));
    painter.drawText(QRect(10, 6, width() - 20, 28),
                     Qt::AlignLeft | Qt::AlignVCenter, chartTitle);

    if (values.isEmpty()) {
        painter.setPen(QColor("#6C7783"));
        painter.setFont(QFont(font().family(), 10));
        painter.drawText(rect().adjusted(12, 35, -12, -12), Qt::AlignCenter,
                         "Нажмите кнопку варианта,\nчтобы показать данные.");
        return;
    }

    const QRectF plot = QRectF(rect()).adjusted(48, 40, -12, -34);
    if (plot.width() <= 0 || plot.height() <= 0) {
        return;
    }

    double maximum = 0.0;
    for (double value : values) {
        maximum = qMax(maximum, value);
    }
    const double topValue = qMax(10.0, qCeil(maximum / 10.0) * 10.0);

    painter.fillRect(plot, QColor("#FBFCFD"));
    painter.setFont(QFont(font().family(), 8));

    for (int i = 0; i <= 5; ++i) {
        const double fraction = i / 5.0;
        const double y = plot.bottom() - fraction * plot.height();
        painter.setPen(QColor("#DCE4EB"));
        painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
        painter.setPen(QColor("#6C7783"));
        painter.drawText(QRectF(1, y - 9, 41, 18), Qt::AlignRight | Qt::AlignVCenter,
                         QString::number(topValue * fraction, 'f', 0));
    }

    const double slotWidth = plot.width() / values.size();
    const double barWidth = qMin(44.0, slotWidth * 0.58);
    for (int i = 0; i < values.size(); ++i) {
        const double value = values.at(i);
        const double barHeight = value / topValue * plot.height();
        const double centerX = plot.left() + slotWidth * (i + 0.5);
        const QRectF bar(centerX - barWidth / 2.0,
                         plot.bottom() - barHeight, barWidth, barHeight);

        painter.setPen(QColor("#467DAA"));
        painter.setBrush(QColor("#538FC1"));
        painter.drawRoundedRect(bar, 2, 2);
        painter.setPen(QColor("#35414D"));
        painter.drawText(QRectF(centerX - slotWidth / 2.0, bar.top() - 20,
                                slotWidth, 18), Qt::AlignCenter,
                         QString::number(value, 'g', 5) + " " + valueUnit);
        painter.setPen(QColor("#6C7783"));
        painter.drawText(QRectF(centerX - slotWidth / 2.0, plot.bottom() + 5,
                                slotWidth, 20), Qt::AlignCenter,
                         QString::number(i + 1));
    }
}
