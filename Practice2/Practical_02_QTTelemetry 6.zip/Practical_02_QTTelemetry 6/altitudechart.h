#ifndef ALTITUDECHART_H
#define ALTITUDECHART_H

#include <QVector>
#include <QString>
#include <QWidget>

class AltitudeChart : public QWidget
{
    Q_OBJECT

public:
    explicit AltitudeChart(QWidget *parent = nullptr);
    void setData(const QVector<double> &values, const QString &title, const QString &unit);
    void clearChart();

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<double> values;
    QString chartTitle = "Гистограмма высоты";
    QString valueUnit = "м";
};

#endif // ALTITUDECHART_H
