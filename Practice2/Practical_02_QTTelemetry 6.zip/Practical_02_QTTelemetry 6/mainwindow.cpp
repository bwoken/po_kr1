#include "mainwindow.h"

#include "altitudechart.h"
#include "telemetry_history.h"
#include "telemetry_record.h"

#include <QDateTime>
#include <QFont>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      outputTextEdit(new QPlainTextEdit(this)),
      altitudeChart(new AltitudeChart(this))
{
    setWindowTitle("Практическая работа № 2 — Телеметрия БПЛА");
    resize(900, 560);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setObjectName("centralWidget");
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(16, 14, 16, 16);
    mainLayout->setSpacing(10);

    QLabel *titleLabel = new QLabel("Телеметрия беспилотного аппарата", centralWidget);
    titleLabel->setObjectName("mainTitle");

    QLabel *descriptionLabel = new QLabel(
        "Задание 2. Выберите вариант, чтобы посмотреть данные и историю высоты.", centralWidget);
    descriptionLabel->setObjectName("descriptionLabel");

    QPushButton *variant2Button = new QPushButton("Вариант 2", centralWidget);
    variant2Button->setObjectName("variant2Button");
    QPushButton *variant3Button = new QPushButton("Вариант 3", centralWidget);
    variant3Button->setObjectName("variant3Button");
    QPushButton *clearButton = new QPushButton("Очистить", centralWidget);
    clearButton->setObjectName("clearButton");

    QHBoxLayout *buttonsLayout = new QHBoxLayout();
    buttonsLayout->setSpacing(8);
    buttonsLayout->addWidget(variant2Button);
    buttonsLayout->addWidget(variant3Button);
    buttonsLayout->addWidget(clearButton);
    buttonsLayout->addStretch();

    // Левая панель с текстовыми данными оформлена в тех же спокойных тонах,
    // что и график справа.
    QFrame *dataPanel = new QFrame(centralWidget);
    dataPanel->setObjectName("dataPanel");
    QVBoxLayout *dataLayout = new QVBoxLayout(dataPanel);
    dataLayout->setContentsMargins(12, 10, 12, 10);
    dataLayout->setSpacing(8);

    QLabel *dataTitle = new QLabel("Данные телеметрии", dataPanel);
    dataTitle->setObjectName("panelTitle");

    outputTextEdit->setReadOnly(true);
    outputTextEdit->setPlaceholderText("Нажмите кнопку варианта, чтобы показать данные.");
    outputTextEdit->setMinimumWidth(310);
    outputTextEdit->setFont(QFont("Menlo", 10));
    outputTextEdit->setObjectName("outputTextEdit");

    dataLayout->addWidget(dataTitle);
    dataLayout->addWidget(outputTextEdit, 1);

    QFrame *chartPanel = new QFrame(centralWidget);
    chartPanel->setObjectName("chartPanel");
    QVBoxLayout *chartLayout = new QVBoxLayout(chartPanel);
    chartLayout->setContentsMargins(8, 8, 8, 8);
    chartLayout->addWidget(altitudeChart);

    QHBoxLayout *contentLayout = new QHBoxLayout();
    contentLayout->setSpacing(12);
    contentLayout->addWidget(dataPanel, 1);
    contentLayout->addWidget(chartPanel, 1);

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(descriptionLabel);
    mainLayout->addLayout(buttonsLayout);
    mainLayout->addLayout(contentLayout, 1);
    setCentralWidget(centralWidget);

    // Единая цветовая схема: светло-серый фон, тонкие границы и мягкий синий акцент.
    setStyleSheet(R"(
        QMainWindow, QWidget#centralWidget {
            background-color: #F3F6F9;
            color: #2B3540;
        }
        QLabel {
            background: transparent;
            color: #2B3540;
        }
        QLabel#mainTitle {
            font-size: 17px;
            font-weight: 600;
            color: #2B3540;
        }
        QLabel#descriptionLabel {
            font-size: 10px;
            color: #6C7783;
        }
        QLabel#panelTitle {
            font-size: 11px;
            font-weight: 600;
            color: #34495B;
        }
        QFrame#dataPanel, QFrame#chartPanel {
            background-color: #F8F9FB;
            border: 1px solid #DCE4EB;
            border-radius: 7px;
        }
        QPlainTextEdit#outputTextEdit {
            background-color: transparent;
            border: none;
            color: #35414D;
            selection-background-color: #C9DDEC;
            padding: 2px;
        }
        QPushButton {
            background-color: #E7EFF6;
            border: 1px solid #C9D8E5;
            border-radius: 5px;
            color: #315F82;
            padding: 7px 15px;
            min-width: 82px;
        }
        QPushButton:hover {
            background-color: #DDEAF4;
            border-color: #AFC7DA;
        }
        QPushButton:pressed {
            background-color: #CCDDEB;
        }
        QPushButton#clearButton {
            background-color: #EEF2F5;
            border-color: #D7E0E7;
            color: #586775;
        }
        QPushButton#clearButton:hover {
            background-color: #E4EAF0;
        }
    )");

    connect(variant2Button, &QPushButton::clicked, this, &MainWindow::showVariant2);
    connect(variant3Button, &QPushButton::clicked, this, &MainWindow::showVariant3);
    connect(clearButton, &QPushButton::clicked, this, &MainWindow::clearOutput);
}

void MainWindow::showVariant2()
{
    TelemetryRecord record("Survey-01");

    // В методичке перечислены контейнеры Qt и параметры.
    // Высоты ниже используются как демонстрационные данные для истории и гистограммы.
    record.add_altitude(100.0);
    record.add_altitude(120.0);
    record.add_altitude(140.0);

    record.set_parameter("speed", 16.4);
    record.set_parameter("battery", 73.0);
    record.set_parameter("temperature", 41.0);
    record.set_parameter("signal", 88.0);

    outputTextEdit->setPlainText(record.toString());
    outputTextEdit->appendPlainText(
        "\nПримечание: высоты 100, 120 и 140 м — демонстрационные данные для графика.");
    altitudeChart->setData(QVector<double>{100.0, 120.0, 140.0},
                           "История высоты (демо)", "м");
}

void MainWindow::showVariant3()
{
    TelemetryHistory history;
    const QDateTime now = QDateTime::currentDateTime();

    // Первая запись повторяет пример из методички.
    // Ещё две записи добавлены для демонстрации истории и построения графика.
    history.add_point(TelemetryPoint(now.addSecs(-60), 100.0, 90.0, 12.0));
    history.add_point(TelemetryPoint(now.addSecs(-30), 105.0, 87.0, 13.0));
    history.add_point(TelemetryPoint(now, 112.0, 84.0, 13.5));

    outputTextEdit->setPlainText(history.toString());
    outputTextEdit->appendPlainText(
        "\nПримечание: первая запись взята из методички; две следующие — демонстрационные.");
    altitudeChart->setData(QVector<double>{100.0, 105.0, 112.0},
                           "История высоты (демо)", "м");
}

void MainWindow::clearOutput()
{
    outputTextEdit->clear();
    altitudeChart->clearChart();
}
