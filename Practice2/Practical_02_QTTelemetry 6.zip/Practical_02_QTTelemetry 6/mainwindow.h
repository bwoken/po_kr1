#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class AltitudeChart;
class QPlainTextEdit;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void showVariant2();
    void showVariant3();
    void clearOutput();

private:
    QPlainTextEdit *outputTextEdit;
    AltitudeChart *altitudeChart;
};

#endif // MAINWINDOW_H
