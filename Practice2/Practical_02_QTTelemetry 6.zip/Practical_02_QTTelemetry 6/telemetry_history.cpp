#include "telemetry_history.h"

#include <QDebug>

void TelemetryHistory::add_point(const TelemetryPoint &point)
{
    points.append(point);
}

int TelemetryHistory::size() const
{
    return points.size();
}

QVector<double> TelemetryHistory::get_altitudes() const
{
    QVector<double> result;
    for (const TelemetryPoint &point : points) {
        result.append(point.get_altitude());
    }
    return result;
}

QString TelemetryHistory::toString() const
{
    QString text;
    text += "Вариант 3. Телеметрия с временными отметками\n\n";
    text += "Количество записей: " + QString::number(size()) + "\n\n";

    if (points.isEmpty()) {
        text += "История пока пуста.\n";
        return text;
    }

    for (int i = 0; i < points.size(); ++i) {
        text += QString::number(i + 1) + ". ";
        text += points.at(i).toString() + "\n";
    }
    return text;
}

void TelemetryHistory::print_all() const
{
    qDebug().noquote() << toString();
}
