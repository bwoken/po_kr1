#ifndef TELEMETRY_HISTORY_H
#define TELEMETRY_HISTORY_H

#include "telemetry_point.h"

#include <QString>
#include <QVector>

class TelemetryHistory
{
public:
    void add_point(const TelemetryPoint &point);
    void print_all() const;
    int size() const;
    QVector<double> get_altitudes() const;
    QString toString() const;

private:
    QVector<TelemetryPoint> points;
};

#endif // TELEMETRY_HISTORY_H
