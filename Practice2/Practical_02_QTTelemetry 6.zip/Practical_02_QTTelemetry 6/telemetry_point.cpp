#include "telemetry_point.h"

#include <QDebug>

TelemetryPoint::TelemetryPoint(const QDateTime &point_time,
                               double point_altitude,
                               double point_battery,
                               double point_speed)
    : time(point_time),
      altitude(point_altitude),
      battery(point_battery),
      speed(point_speed)
{
}

QString TelemetryPoint::toString() const
{
    return time.toString(Qt::ISODate)
           + " | Высота: " + QString::number(altitude, 'g', 6) + " м"
           + " | Заряд: " + QString::number(battery, 'g', 6) + "%"
           + " | Скорость: " + QString::number(speed, 'g', 6) + " м/с";
}

double TelemetryPoint::get_altitude() const
{
    return altitude;
}

void TelemetryPoint::print() const
{
    qDebug().noquote() << toString();
}
