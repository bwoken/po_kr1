#ifndef TELEMETRY_POINT_H
#define TELEMETRY_POINT_H

#include <QDateTime>
#include <QString>

class TelemetryPoint
{
public:
    TelemetryPoint(const QDateTime &point_time,
                   double point_altitude,
                   double point_battery,
                   double point_speed);

    void print() const;
    QString toString() const;
    double get_altitude() const;

private:
    QDateTime time;
    double altitude;
    double battery;
    double speed;
};

#endif // TELEMETRY_POINT_H
