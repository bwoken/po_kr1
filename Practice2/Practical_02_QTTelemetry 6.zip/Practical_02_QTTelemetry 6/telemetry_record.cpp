#include "telemetry_record.h"

#include <QDebug>

TelemetryRecord::TelemetryRecord(const QString &name)
    : drone_name(name)
{
}

void TelemetryRecord::add_altitude(double altitude)
{
    if (altitude >= 0.0) {
        altitude_history.append(altitude);
    }
}

void TelemetryRecord::set_parameter(const QString &name, double value)
{
    parameters.insert(name, value);
}

double TelemetryRecord::average_altitude() const
{
    if (altitude_history.isEmpty()) {
        return 0.0;
    }

    double sum = 0.0;
    for (double value : altitude_history) {
        sum += value;
    }
    return sum / altitude_history.size();
}

double TelemetryRecord::get_parameter(const QString &name) const
{
    return parameters.value(name, 0.0);
}

QString TelemetryRecord::toString() const
{
    QString text;
    text += "Вариант 2. Телеметрия с классами Qt\n\n";
    text += "БПЛА: " + drone_name + "\n";
    text += "История высоты: ";

    for (int i = 0; i < altitude_history.size(); ++i) {
        if (i > 0) {
            text += ", ";
        }
        text += QString::number(altitude_history.at(i), 'g', 6);
    }

    text += " м\nСредняя высота: ";
    text += QString::number(average_altitude(), 'g', 6) + " м\n\n";
    text += "Параметры:\n";

    for (auto it = parameters.cbegin(); it != parameters.cend(); ++it) {
        text += "  " + it.key() + ": " + QString::number(it.value(), 'g', 6) + "\n";
    }
    return text;
}

void TelemetryRecord::print_parameters() const
{
    qDebug().noquote() << toString();
}
