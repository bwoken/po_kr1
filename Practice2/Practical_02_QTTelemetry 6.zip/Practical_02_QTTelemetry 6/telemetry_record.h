#ifndef TELEMETRY_RECORD_H
#define TELEMETRY_RECORD_H

#include <QMap>
#include <QString>
#include <QVector>

class TelemetryRecord
{
public:
    explicit TelemetryRecord(const QString &name);

    void add_altitude(double altitude);
    void set_parameter(const QString &name, double value);
    double average_altitude() const;
    double get_parameter(const QString &name) const;
    void print_parameters() const;
    QString toString() const;

private:
    QString drone_name;
    QVector<double> altitude_history;
    QMap<QString, double> parameters;
};

#endif // TELEMETRY_RECORD_H
