TEMPLATE = subdirs
SUBDIRS += integration task_01_telemetry task_02_fleet task_03_failsafe
