#pragma once

#include <QGraphicsScene>
#include <QPointF>
#include <deque>

class QGraphicsEllipseItem;
class QGraphicsPathItem;

class FlightScene final : public QGraphicsScene {
public:
    explicit FlightScene(QObject* parent = nullptr);
    void append_sample(double time, double altitude);

private:
    std::deque<QPointF> samples_;
    QGraphicsEllipseItem* marker_;
    QGraphicsPathItem* trajectory_;
};
