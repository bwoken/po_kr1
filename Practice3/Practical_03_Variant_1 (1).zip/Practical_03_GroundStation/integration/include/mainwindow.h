#pragma once

#include "station.h"
#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <memory>

#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
QT_CHARTS_USE_NAMESPACE
#endif

class FlightScene;

namespace Ui { class MainWindow; }

class MainWindow final : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;

private slots:
    void start();
    void pause();
    void reset();
    void toggle_gps();
    void update_telemetry(double altitude, double error, double control);
    void update_fleet();
    void update_chart(double altitude);
    void update_scene(double altitude);
    void show_fault(const QString& reason);
    void update_navigation(const QString& name);

private:
    void set_status(const QString& text, const char* tone);
    void add_event(const QString& description);
    void refresh_controls();

    std::unique_ptr<Ui::MainWindow> ui;
    Station station_;
    QLineSeries* altitude_series_;
    QValueAxis* time_axis_;
    QValueAxis* altitude_axis_;
    FlightScene* scene_;
    bool faulted_ = false;
    bool warning_shown_ = false;
    bool gps_valid_ = true;
};
