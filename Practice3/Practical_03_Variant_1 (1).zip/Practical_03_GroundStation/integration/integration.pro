QT += widgets charts
TEMPLATE = app
TARGET = ground_station
CONFIG += c++17
win32-msvc*: QMAKE_CXXFLAGS += /utf-8
INCLUDEPATH += include
SOURCES += src/main.cpp src/mainwindow.cpp src/flight_scene.cpp
HEADERS += include/mainwindow.h include/flight_scene.h
FORMS += forms/mainwindow.ui
include(../model/model.pri)
