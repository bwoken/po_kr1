#include "flight_scene.h"

#include <QGraphicsEllipseItem>
#include <QGraphicsPathItem>
#include <QPainterPath>
#include <algorithm>
#include <iterator>

namespace {
constexpr double baseline = 142;
constexpr double left = 34;
constexpr double plot_width = 234;
constexpr double altitude_scale = 0.22;
}

FlightScene::FlightScene(QObject* parent) : QGraphicsScene(0, 0, 292, 168, parent)
{
    setBackgroundBrush(QColor("#0c1422"));
    for (int height = 0; height <= 500; height += 100) {
        const double y = baseline - altitude_scale * height;
        addLine(left, y, left + plot_width, y, QPen(QColor("#24374d")));
        auto* label = addSimpleText(QString::number(height));
        label->setBrush(QColor("#a7bacd"));
        label->setPos(1, y - 8);
    }
    auto* label = addSimpleText(QStringLiteral("м"));
    label->setBrush(QColor("#92aabd"));
    label->setPos(9, 7);
    trajectory_ = addPath(QPainterPath(), QPen(QColor("#4794b0"), 2));
    marker_ = addEllipse(-5, -5, 10, 10, QPen(QColor("#eaffff"), 1.4),
                         QBrush(QColor("#65deeb")));
    marker_->hide();
}

void FlightScene::append_sample(double time, double altitude)
{
    samples_.emplace_back(time, altitude);
    while (time - samples_.front().x() > 12.0)
        samples_.pop_front();

    const double start = std::max(0.0, time - 12.0);
    const auto project = [start](const QPointF& sample) {
        return QPointF(left + (sample.x() - start) * plot_width / 12.0,
                       baseline - std::clamp(sample.y(), 0.0, 540.0) * altitude_scale);
    };
    QPainterPath path(project(samples_.front()));
    for (auto it = std::next(samples_.cbegin()); it != samples_.cend(); ++it)
        path.lineTo(project(*it));
    trajectory_->setPath(path);
    marker_->setPos(project(samples_.back()));
    marker_->show();
}
