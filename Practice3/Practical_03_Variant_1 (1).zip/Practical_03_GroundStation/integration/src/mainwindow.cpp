#include "mainwindow.h"
#include "flight_scene.h"
#include "ui_mainwindow.h"

#include <QHeaderView>
#include <QMessageBox>
#include <QStyle>
#include <algorithm>

namespace {

const char theme[] = R"(
QMainWindow, QWidget#centralwidget { background: #0b1220; }
QWidget { color: #e9f1fa; font-size: 13px; }
QLabel#title { font-size: 28px; font-weight: bold; }
QLabel#subtitle { color: #9ab2c9; }
QLabel[role="heading"] { font-size: 15px; font-weight: bold; }
QLabel[role="caption"] { color: #a7bacd; }
QLabel[role="value"] { color: #7ce3ee; font-size: 25px; font-weight: bold; }
QLabel[tone="idle"] { color: #adc0d4; }
QLabel[tone="good"] { color: #6fe5a8; }
QLabel[tone="caution"] { color: #ffcf75; }
QLabel[tone="fault"] { color: #ff838a; }
QLabel#labelStatus, QLabel#labelNavigation {
    font-weight: bold; background: #17253a; border-radius: 7px; padding: 7px 10px;
}
QFrame[panel="true"] {
    background: #111c2d; border: 1px solid #263a53; border-radius: 10px;
}
QPushButton, QDoubleSpinBox {
    background: #1b2d43; border: 1px solid #3b516b; border-radius: 7px; padding: 6px 10px;
}
QPushButton:hover { background: #29445f; }
QPushButton:focus, QDoubleSpinBox:focus { border-color: #75e2ee; }
QPushButton#btnStart { background: #69d9e9; color: #0b2535; font-weight: bold; }
QPushButton#btnStart:hover { background: #a2edf6; }
QPushButton#btnFaultSensor { color: #ffb5b8; }
QPushButton:disabled, QPushButton#btnStart:disabled, QPushButton#btnFaultSensor:disabled {
    background: #162234; color: #788ba0; border-color: #273a50;
}
QTableWidget, QListWidget, QGraphicsView {
    background: #0c1422; border: 0; alternate-background-color: #142238;
}
QTableWidget { gridline-color: #25384d; }
QHeaderView::section {
    color: #a7bacd; background: #1b2b40; border: 0; padding: 5px;
}
QListWidget::item { padding: 4px; }
QMessageBox { background: #111c2d; }
)";
}

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), ui(std::make_unique<Ui::MainWindow>()),
      altitude_series_(new QLineSeries), time_axis_(new QValueAxis), altitude_axis_(new QValueAxis), scene_(new FlightScene(this))
{
    ui->setupUi(this);
    setStyleSheet(QString::fromLatin1(theme));
    resize(1080, 750);

    auto* chart = new QChart;
    chart->setTheme(QChart::ChartThemeDark);
    chart->setBackgroundBrush(QColor("#0c1422"));
    chart->setBackgroundRoundness(7);
    chart->setMargins({4, 4, 10, 2});
    chart->legend()->hide();
    chart->addSeries(altitude_series_);
    altitude_series_->setPen(QPen(QColor("#6adfeb"), 2.5));
    time_axis_->setRange(0, 12);
    time_axis_->setLabelFormat("%.0f");
    time_axis_->setTitleText(QStringLiteral("Время, с"));
    time_axis_->setTickCount(5);
    altitude_axis_->setRange(100, 340);
    altitude_axis_->setTitleText(QStringLiteral("Высота, м"));
    altitude_axis_->setLabelFormat("%.0f");
    chart->addAxis(time_axis_, Qt::AlignBottom);
    chart->addAxis(altitude_axis_, Qt::AlignLeft);
    altitude_series_->attachAxis(time_axis_);
    altitude_series_->attachAxis(altitude_axis_);
    auto* chart_view = new QChartView(chart, ui->chartHost);
    chart_view->setObjectName(QStringLiteral("chartView"));
    chart_view->setFrameShape(QFrame::NoFrame);
    chart_view->setRenderHint(QPainter::Antialiasing);
    ui->chartLayout->addWidget(chart_view);
    ui->graphicsView->setScene(scene_);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    ui->tableFleet->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableFleet->verticalHeader()->hide();
    ui->tableFleet->verticalHeader()->setDefaultSectionSize(25);
    for (const UAV* aircraft : station_.fleet()) {
        const int row = ui->tableFleet->rowCount();
        ui->tableFleet->insertRow(row);
        ui->tableFleet->setItem(row, 0, new QTableWidgetItem(aircraft->type()));
        ui->tableFleet->setItem(row, 1, new QTableWidgetItem(QString::number(aircraft->motor_count())));
        ui->tableFleet->setItem(row, 2, new QTableWidgetItem);
        ui->tableFleet->setItem(row, 3, new QTableWidgetItem);
    }

    auto& autopilot = station_.autopilot();
    connect(ui->btnStart, &QPushButton::clicked, this, &MainWindow::start);
    connect(ui->btnPause, &QPushButton::clicked, this, &MainWindow::pause);
    connect(ui->btnReset, &QPushButton::clicked, this, &MainWindow::reset);
    connect(ui->btnFaultSensor, &QPushButton::clicked, this, [this] {
        station_.fail_sensor();
        ui->btnFaultSensor->setEnabled(false);
    });
    connect(ui->btnGps, &QPushButton::clicked, this, &MainWindow::toggle_gps);
    connect(ui->spinTarget, qOverload<double>(&QDoubleSpinBox::valueChanged),
            &autopilot, &Autopilot::set_target_altitude);
    connect(&autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_telemetry);
    connect(&autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_fleet);
    connect(&autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_chart);
    connect(&autopilot, &Autopilot::telemetry_updated, this, &MainWindow::update_scene);
    connect(&autopilot, &Autopilot::fault_detected, this, &MainWindow::show_fault);
    connect(&station_.navigation(), &NavigationManager::active_system_changed,
            this, &MainWindow::update_navigation);

    set_status(QStringLiteral("Stopped"), "idle");
    refresh_controls();
}

MainWindow::~MainWindow() = default;

void MainWindow::start()
{
    station_.start();
    set_status(QStringLiteral("Running"), "good");
    add_event(QStringLiteral("Цикл запущен"));
    refresh_controls();
}

void MainWindow::pause()
{
    station_.pause();
    set_status(QStringLiteral("Paused"), "caution");
    add_event(QStringLiteral("Пауза"));
    refresh_controls();
}

void MainWindow::reset()
{
    faulted_ = false;
    warning_shown_ = false;
    station_.reset();
    set_status(QStringLiteral("Mission status: Active"), "good");
    add_event(QStringLiteral("Сброс выполнен, гироскоп восстановлен"));
    refresh_controls();
}

void MainWindow::toggle_gps()
{
    gps_valid_ = !gps_valid_;
    station_.set_gps_valid(gps_valid_);
    ui->btnGps->setText(gps_valid_ ? QStringLiteral("Отказ GPS") : QStringLiteral("Восстановить GPS"));
}

void MainWindow::set_status(const QString& text, const char* tone)
{
    ui->labelStatus->setText(text);
    ui->labelStatus->setProperty("tone", QString::fromLatin1(tone));
    style()->unpolish(ui->labelStatus);
    style()->polish(ui->labelStatus);
}

void MainWindow::refresh_controls()
{
    const bool running = station_.running();
    ui->btnStart->setEnabled(!running && !faulted_);
    ui->btnPause->setEnabled(running);
    ui->btnFaultSensor->setEnabled(running);
    ui->btnGps->setEnabled(running);
    update_fleet();
}

void MainWindow::add_event(const QString& description)
{
    const double time = station_.autopilot().elapsed_seconds();
    ui->eventLog->addItem(QStringLiteral("[%1 с] %2").arg(time, 0, 'f', 1).arg(description));
    ui->eventLog->scrollToBottom();
}

void MainWindow::update_telemetry(double altitude, double error, double control)
{
    ui->labelAltitude->setText(QString::number(altitude, 'f', 1) + QStringLiteral(" м"));
    ui->labelError->setText(QString::number(error, 'f', 1) + QStringLiteral(" м"));
    ui->labelOutput->setText(QString::number(control, 'f', 2));
}

void MainWindow::update_fleet()
{
    const auto& fleet = station_.fleet();
    for (int row = 0; row < ui->tableFleet->rowCount(); ++row) {
        ui->tableFleet->item(row, 2)->setText(QStringLiteral("%1 %").arg(fleet.at(row)->charge()));
        QString status = QStringLiteral("Connected");
        if (row == 0 && faulted_)
            status = QStringLiteral("Failsafe");
        else if (row == 0 && station_.running())
            status = QStringLiteral("Active");
        ui->tableFleet->item(row, 3)->setText(status);
    }
}

void MainWindow::update_chart(double altitude)
{
    const double time = station_.autopilot().elapsed_seconds();
    altitude_series_->append(time, altitude);
    if (altitude_series_->count() > 121)
        altitude_series_->removePoints(0, altitude_series_->count() - 121);
    const double start = std::max(0.0, time - 12.0);
    time_axis_->setRange(start, start + 12.0);
    if (altitude < altitude_axis_->min() || altitude > altitude_axis_->max())
        altitude_axis_->setRange(std::min(altitude_axis_->min(), altitude - 15.0),
                                std::max(altitude_axis_->max(), altitude + 15.0));
}

void MainWindow::update_scene(double altitude)
{
    scene_->append_sample(station_.autopilot().elapsed_seconds(), altitude);
}

void MainWindow::show_fault(const QString& reason)
{
    faulted_ = true;
    set_status(QStringLiteral("FAULT · ") + reason, "fault");
    add_event(reason);
    refresh_controls();
    if (!warning_shown_) {
        warning_shown_ = true;
        QMessageBox::warning(this, QStringLiteral("Авария автопилота"), reason);
    }
}

void MainWindow::update_navigation(const QString& name)
{
    const bool backup = name == QStringLiteral("INS");
    ui->labelNavigation->setText(name.isEmpty() ? QStringLiteral("Навигация недоступна")
                                                : QStringLiteral("Навигация · ") + name);
    ui->labelNavigation->setProperty("tone", backup ? QStringLiteral("caution") : QStringLiteral("good"));
    style()->unpolish(ui->labelNavigation);
    style()->polish(ui->labelNavigation);
    if (!name.isEmpty())
        add_event(backup ? QStringLiteral("GPS недоступен, активна INS")
                         : QStringLiteral("Активен GPS"));
}
