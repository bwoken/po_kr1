#include "autopilot.h"
#include "controller.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"

#include <cmath>

Autopilot::Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
                     NavigationManager* navigation, FlightController* controller, QObject* parent)
    : QObject(parent), vehicle_(vehicle), sensors_(sensors),
      navigation_(navigation), controller_(controller) {}

void Autopilot::set_target_altitude(double altitude)
{
    if (std::isfinite(altitude) && altitude >= 50.0 && altitude <= 500.0)
        target_altitude_ = altitude;
}

double Autopilot::elapsed_seconds() const
{
    return ticks_ * (interval_ms / 1000.0);
}

void Autopilot::run_cycle()
{
    if (!vehicle_) {
        emit fault_detected(QStringLiteral("БПЛА не задан"));
        return;
    }
    for (const Sensor* sensor : sensors_) {
        if (!sensor || !sensor->is_ready() || !std::isfinite(sensor->read())) {
            emit fault_detected(QStringLiteral("Отказ сенсора: %1")
                .arg(sensor ? sensor->name() : QStringLiteral("неизвестный")));
            return;
        }
    }
    const NavigationSystem* source = navigation_ ? navigation_->select_source() : nullptr;
    if (!source) {
        emit fault_detected(QStringLiteral("Навигация недоступна"));
        return;
    }
    if (!controller_) {
        emit fault_detected(QStringLiteral("Регулятор не задан"));
        return;
    }
    constexpr double dt = interval_ms / 1000.0;
    const double altitude = source->get_position().altitude;
    if (!std::isfinite(altitude) || altitude < 0.0) {
        emit fault_detected(QStringLiteral("Некорректная высота"));
        return;
    }
    const double error = target_altitude_ - altitude;
    const double control = controller_->calculate_control(error, dt);
    if (!std::isfinite(control)) {
        emit fault_detected(QStringLiteral("Некорректный выход регулятора"));
        return;
    }
    ++ticks_;
    emit telemetry_updated(altitude, error, control);
    vehicle_->advance(control, dt);
}
