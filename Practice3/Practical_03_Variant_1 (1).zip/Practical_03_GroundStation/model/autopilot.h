#pragma once

#include <QObject>
#include <vector>

class UAV;
class Sensor;
class NavigationManager;
class FlightController;

class Autopilot final : public QObject {
    Q_OBJECT
public:
    static constexpr int interval_ms = 100;

    Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
              NavigationManager* navigation, FlightController* controller,
              QObject* parent = nullptr);
    void set_target_altitude(double altitude);
    double elapsed_seconds() const;

public slots:
    void run_cycle();

signals:
    void telemetry_updated(double altitude, double error, double control);
    void fault_detected(const QString& reason);

private:
    UAV* vehicle_;
    std::vector<Sensor*> sensors_;
    NavigationManager* navigation_;
    FlightController* controller_;
    double target_altitude_ = 200.0;
    int ticks_ = 0;
};
