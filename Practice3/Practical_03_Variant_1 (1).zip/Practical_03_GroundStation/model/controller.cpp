#include "controller.h"
#include <algorithm>
#include <cmath>
#include <limits>

PIDController::PIDController(double kp, double ki, double kd)
    : kp_(kp), ki_(ki), kd_(kd) {}

double PIDController::calculate_control(double error, double dt)
{
    if (!std::isfinite(error) || !std::isfinite(dt) || dt <= 0.0)
        return std::numeric_limits<double>::quiet_NaN();
    integral_ = std::clamp(integral_ + error * dt, -30.0, 30.0);
    const double derivative = (error - previous_error_) / dt;
    previous_error_ = error;
    return kp_ * error + ki_ * integral_ + kd_ * derivative;
}

SimpleController::SimpleController(double coefficient) : coefficient_(coefficient) {}
double SimpleController::calculate_control(double error, double)
{
    return coefficient_ * error;
}
