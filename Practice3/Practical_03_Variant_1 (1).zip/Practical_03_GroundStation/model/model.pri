INCLUDEPATH += $$PWD
HEADERS += $$PWD/uav.h $$PWD/sensor.h $$PWD/navigation.h $$PWD/controller.h \
           $$PWD/autopilot.h $$PWD/station.h
SOURCES += $$PWD/uav.cpp $$PWD/sensor.cpp $$PWD/navigation.cpp $$PWD/controller.cpp \
           $$PWD/autopilot.cpp $$PWD/station.cpp
