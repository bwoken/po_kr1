#include "navigation.h"
#include "uav.h"

GPSNavigation::GPSNavigation(const UAV& vehicle) : vehicle_(vehicle) {}
Position GPSNavigation::get_position() const { return {55.75, 37.61, vehicle_.altitude()}; }
bool GPSNavigation::is_valid() const { return valid_; }
QString GPSNavigation::system_name() const { return QStringLiteral("GPS"); }
void GPSNavigation::set_valid(bool valid) { valid_ = valid; }

InertialNavigation::InertialNavigation(const UAV& vehicle) : vehicle_(vehicle) {}
Position InertialNavigation::get_position() const { return {55.75, 37.61, vehicle_.altitude()}; }
bool InertialNavigation::is_valid() const { return true; }
QString InertialNavigation::system_name() const { return QStringLiteral("INS"); }

NavigationManager::NavigationManager(NavigationSystem& primary, NavigationSystem& backup)
    : primary_(primary), backup_(backup)
{
}

const NavigationSystem* NavigationManager::select_source()
{
    const NavigationSystem* selected = nullptr;
    if (primary_.is_valid())
        selected = &primary_;
    else if (backup_.is_valid())
        selected = &backup_;

    if (selected != active_) {
        active_ = selected;
        emit active_system_changed(active_ ? active_->system_name() : QString());
    }
    return active_;
}
