#pragma once
#include <QObject>

class UAV;

struct Position {
    double latitude;
    double longitude;
    double altitude;
};

class NavigationSystem {
public:
    virtual ~NavigationSystem() = default;
    virtual Position get_position() const = 0;
    virtual bool is_valid() const = 0;
    virtual QString system_name() const = 0;
};

class GPSNavigation final : public NavigationSystem {
public:
    explicit GPSNavigation(const UAV& vehicle);
    Position get_position() const override;
    bool is_valid() const override;
    QString system_name() const override;
    void set_valid(bool valid);

private:
    const UAV& vehicle_;
    bool valid_ = true;
};

class InertialNavigation final : public NavigationSystem {
public:
    explicit InertialNavigation(const UAV& vehicle);
    Position get_position() const override;
    bool is_valid() const override;
    QString system_name() const override;

private:
    const UAV& vehicle_;
};

class NavigationManager final : public QObject {
    Q_OBJECT
public:
    NavigationManager(NavigationSystem& primary, NavigationSystem& backup);
    const NavigationSystem* select_source();

signals:
    void active_system_changed(const QString& name);

private:
    NavigationSystem& primary_;
    NavigationSystem& backup_;
    const NavigationSystem* active_ = nullptr;
};
