#include "station.h"

Station::Station()
{
    timer_.setTimerType(Qt::PreciseTimer);
    timer_.setInterval(Autopilot::interval_ms);
    QObject::connect(&timer_, &QTimer::timeout, &autopilot_, &Autopilot::run_cycle);
    QObject::connect(&autopilot_, &Autopilot::fault_detected, &timer_, &QTimer::stop);
}

Autopilot& Station::autopilot() { return autopilot_; }
NavigationManager& Station::navigation() { return navigation_; }
const std::vector<UAV*>& Station::fleet() const { return fleet_; }
bool Station::running() const { return timer_.isActive(); }
void Station::start() { if (!running()) timer_.start(); }
void Station::pause() { timer_.stop(); }
void Station::fail_sensor() { gyro_.set_ready(false); }
void Station::set_gps_valid(bool valid) { gps_.set_valid(valid); }

void Station::reset()
{
    gyro_.set_ready(true);
    start();
}
