#pragma once

#include "autopilot.h"
#include "controller.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"

#include <QTimer>

class Station {
public:
    Station();
    Autopilot& autopilot();
    NavigationManager& navigation();
    const std::vector<UAV*>& fleet() const;
    bool running() const;
    void start();
    void pause();
    void fail_sensor();
    void reset();
    void set_gps_valid(bool valid);

private:
    Quadcopter quad_;
    Hexacopter hexa_;
    Octocopter octo_;
    const std::vector<UAV*> fleet_{&quad_, &hexa_, &octo_};
    Gyroscope gyro_;
    Accelerometer accelerometer_;
    Barometer barometer_;
    GPSNavigation gps_{quad_};
    InertialNavigation ins_{quad_};
    NavigationManager navigation_{gps_, ins_};
    PIDController controller_{0.5, 0.1, 0.05};
    Autopilot autopilot_{&quad_, {&gyro_, &accelerometer_, &barometer_}, &navigation_, &controller_};
    QTimer timer_;
};
