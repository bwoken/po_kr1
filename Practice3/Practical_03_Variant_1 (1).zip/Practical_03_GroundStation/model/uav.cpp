#include "uav.h"
#include <algorithm>

UAV::UAV(double charge) : charge_(charge) {}
double UAV::altitude() const { return altitude_; }
int UAV::charge() const { return qRound(charge_); }

void UAV::advance(double control, double dt)
{
    // A simulated climb rate in m/s, limited by the demo's actuator.
    const double speed = std::clamp(control, -35.0, 35.0);
    altitude_ = std::max(0.0, altitude_ + speed * dt);
    charge_ = std::max(0.0, charge_ - 0.15 * dt);
}

Quadcopter::Quadcopter() : UAV(86) {}
QString Quadcopter::type() const { return QStringLiteral("Quadcopter"); }
int Quadcopter::motor_count() const { return 4; }

Hexacopter::Hexacopter() : UAV(73) {}
QString Hexacopter::type() const { return QStringLiteral("Hexacopter"); }
int Hexacopter::motor_count() const { return 6; }

Octocopter::Octocopter() : UAV(94) {}
QString Octocopter::type() const { return QStringLiteral("Octocopter"); }
int Octocopter::motor_count() const { return 8; }
