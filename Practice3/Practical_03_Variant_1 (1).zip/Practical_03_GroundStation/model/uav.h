#pragma once
#include <QString>

class UAV {
public:
    virtual ~UAV() = default;
    virtual QString type() const = 0;
    virtual int motor_count() const = 0;
    double altitude() const;
    int charge() const;
    void advance(double control, double dt);

protected:
    explicit UAV(double charge);

private:
    double altitude_ = 150.0;
    double charge_;
};

class Quadcopter final : public UAV {
public:
    Quadcopter();
    QString type() const override;
    int motor_count() const override;
};

class Hexacopter final : public UAV {
public:
    Hexacopter();
    QString type() const override;
    int motor_count() const override;
};

class Octocopter final : public UAV {
public:
    Octocopter();
    QString type() const override;
    int motor_count() const override;
};
