#include "station.h"

#include <QCoreApplication>
#include <QTextStream>
#include <cmath>
#include <cstdlib>

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);
    Station station;
    QTextStream out(stdout);
    double altitude_before_pause = 0.0;
    double time_before_pause = 0.0;
    int samples = 0;

    QObject::connect(&station.autopilot(), &Autopilot::telemetry_updated, &app,
                     [&](double altitude, double error, double control) {
        ++samples;
        out << station.autopilot().elapsed_seconds() << " s | altitude=" << altitude
            << " m | error=" << error << " m | output=" << control << Qt::endl;
        if (samples == 4) {
            station.pause();
            altitude_before_pause = altitude;
            time_before_pause = station.autopilot().elapsed_seconds();
            out << "Paused" << Qt::endl;
            QTimer::singleShot(450, &app, [&] {
                if (station.running() || samples != 4 ||
                    station.autopilot().elapsed_seconds() != time_before_pause) {
                    app.exit(EXIT_FAILURE);
                    return;
                }
                station.start();
                out << "Running (resumed)" << Qt::endl;
            });
        } else if (samples == 7) {
            const bool continued = altitude > altitude_before_pause
                && std::abs(station.autopilot().elapsed_seconds() - time_before_pause - 0.3) < 1e-8;
            out << (continued ? "PASS: pause and resume" : "FAIL: simulation state") << Qt::endl;
            app.exit(continued ? EXIT_SUCCESS : EXIT_FAILURE);
        }
    });
    QObject::connect(&station.autopilot(), &Autopilot::fault_detected, &app,
                     [&] { app.exit(EXIT_FAILURE); });
    QTimer::singleShot(3000, &app, [&] { app.exit(EXIT_FAILURE); });
    station.start();
    out << "Running | interval 100 ms" << Qt::endl;
    return app.exec();
}
