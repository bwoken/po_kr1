QT = core
TEMPLATE = app
TARGET = task_01_telemetry
CONFIG += c++17 console
CONFIG -= app_bundle
win32-msvc*: QMAKE_CXXFLAGS += /utf-8
SOURCES += main.cpp
include(../model/model.pri)
