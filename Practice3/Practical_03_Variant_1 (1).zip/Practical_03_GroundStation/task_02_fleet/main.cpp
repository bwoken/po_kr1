#include "station.h"

#include <QCoreApplication>
#include <QPointF>
#include <QTextStream>
#include <cstdlib>
#include <vector>

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);
    Station station;
    QTextStream out(stdout);
    out << "Aircraft       | Motors | Charge | Status" << Qt::endl;
    for (const UAV* vehicle : station.fleet())
        out << vehicle->type().leftJustified(14) << " | "
            << QString::number(vehicle->motor_count()).leftJustified(6)
            << " | " << vehicle->charge() << " %   | Connected" << Qt::endl;

    std::vector<QPointF> chart;
    std::vector<QPointF> trajectory;
    int fleet_updates = 0;
    const auto& autopilot = station.autopilot();
    QObject::connect(&autopilot, &Autopilot::telemetry_updated, &app, [&](double) {
        ++fleet_updates;
        out << "Fleet update | " << station.fleet().front()->type() << ": "
            << station.fleet().front()->charge() << " % | Active" << Qt::endl;
    });
    QObject::connect(&autopilot, &Autopilot::telemetry_updated, &app, [&](double altitude) {
        chart.emplace_back(autopilot.elapsed_seconds(), altitude);
        out << "Chart point | t=" << chart.back().x()
            << " s, altitude=" << chart.back().y() << " m" << Qt::endl;
    });
    QObject::connect(&autopilot, &Autopilot::telemetry_updated, &app, [&](double altitude) {
        trajectory.emplace_back(autopilot.elapsed_seconds() * 20.0, -altitude);
        out << "Trajectory marker | x=" << trajectory.back().x()
            << ", y=" << trajectory.back().y() << Qt::endl;
        if (trajectory.size() == 5) {
            const bool updated = fleet_updates == 5 && chart.size() == 5
                && chart.back().y() > chart.front().y()
                && trajectory.back().x() > trajectory.front().x();
            out << (updated ? "PASS: three views updated" : "FAIL: view updates") << Qt::endl;
            app.exit(updated ? EXIT_SUCCESS : EXIT_FAILURE);
        }
    });
    QObject::connect(&autopilot, &Autopilot::fault_detected, &app,
                     [&] { app.exit(EXIT_FAILURE); });
    QTimer::singleShot(2500, &app, [&] { app.exit(EXIT_FAILURE); });
    station.start();
    return app.exec();
}
