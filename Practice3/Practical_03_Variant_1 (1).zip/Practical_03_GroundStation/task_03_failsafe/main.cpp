#include "station.h"

#include <QCoreApplication>
#include <QStringList>
#include <QTextStream>
#include <cstdlib>

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);
    Station station;
    QTextStream out(stdout);
    QStringList events;
    int received = 0;
    int alerts = 0;
    bool warned = false;

    QObject::connect(&station.autopilot(), &Autopilot::telemetry_updated, &app, [&] {
        ++received;
        if (received == 3 || received == 6)
            station.fail_sensor();
        if (received == 7) {
            const bool passed = events.size() == 2 && alerts == 2 && station.running();
            out << (passed ? "PASS: failsafe and reset" : "FAIL: failsafe and reset") << Qt::endl;
            app.exit(passed ? EXIT_SUCCESS : EXIT_FAILURE);
        }
    });

    auto report_fault = [&](const QString& reason) {
        out << "FAULT | " << reason << Qt::endl;
        events.append(QStringLiteral("[%1 s] %2")
                          .arg(station.autopilot().elapsed_seconds(), 0, 'f', 1).arg(reason));
        out << "Journal | " << events.last() << Qt::endl;
        if (!warned) {
            warned = true;
            ++alerts;
            out << "WARNING | " << reason << Qt::endl;
        }
    };
    QObject::connect(&station.autopilot(), &Autopilot::fault_detected, &app,
                     [&](const QString& reason) {
        report_fault(reason);
        const int frozen = received;
        if (station.running()) {
            app.exit(EXIT_FAILURE);
            return;
        }
        QTimer::singleShot(250, &app, [&, frozen] {
            if (station.running() || received != frozen) {
                app.exit(EXIT_FAILURE);
                return;
            }
            warned = false;
            station.reset();
            out << "Mission status: Active" << Qt::endl;
        });
    });
    QTimer::singleShot(3000, &app, [&] { app.exit(EXIT_FAILURE); });
    station.start();
    return app.exec();
}
