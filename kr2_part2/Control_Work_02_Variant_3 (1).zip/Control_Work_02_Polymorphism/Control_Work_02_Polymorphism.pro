TEMPLATE = subdirs
SUBDIRS += all_tasks_gui \
    task_01_uav \
    task_02_sensors \
    task_03_controllers
