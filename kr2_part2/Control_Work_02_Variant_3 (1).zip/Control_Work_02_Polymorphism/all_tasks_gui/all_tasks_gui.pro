QT += widgets
TEMPLATE = app
TARGET = all_tasks_gui
CONFIG += c++17
win32-msvc*: QMAKE_CXXFLAGS += /utf-8

SOURCES += main.cpp demo_window.cpp autopilot_demo.cpp autopilot.cpp navigation.cpp
HEADERS += demo_window.h autopilot_demo.h autopilot.h navigation.h

include(../task_01_uav/uav_module.pri)
include(../task_02_sensors/sensor_module.pri)
include(../task_03_controllers/controller_module.pri)
