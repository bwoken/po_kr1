#include "autopilot.h"

#include "controller.h"
#include "navigation.h"
#include "sensor.h"

#include <QDebug>
#include <cmath>

namespace {

constexpr double target_altitude = 200.0;
constexpr double control_step = 0.1;

bool valid_position(const Position& position)
{
    return std::isfinite(position.latitude) && std::abs(position.latitude) <= 90.0
        && std::isfinite(position.longitude) && std::abs(position.longitude) <= 180.0
        && std::isfinite(position.altitude) && position.altitude >= 0.0;
}

void abort_cycle(const QString& reason)
{
    qDebug().noquote() << QStringLiteral("Autopilot cycle aborted");
    qDebug().noquote() << QStringLiteral("Reason:") << reason;
}

} // namespace

Autopilot::Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
                     NavigationSystem* navigation, FlightController* controller)
    : vehicle_(vehicle), sensors_(sensors), navigation_(navigation), controller_(controller)
{
}

void Autopilot::run_cycle()
{
    qDebug().noquote() << QStringLiteral("Autopilot cycle started");
    if (vehicle_ == nullptr) {
        qDebug().noquote() << QStringLiteral("Error: vehicle is not set");
        return;
    }

    if (sensors_.empty()) {
        abort_cycle(QStringLiteral("sensor failure (no sensors configured)"));
        return;
    }

    // Each sensor configured for this demo is critical.
    for (Sensor* sensor : sensors_) {
        if (sensor == nullptr) {
            qDebug().noquote() << QStringLiteral("Error: sensor is not set");
            abort_cycle(QStringLiteral("sensor failure"));
            return;
        }
        if (!sensor->is_ready()) {
            qDebug().noquote() << sensor->name() + QStringLiteral(": sensor is not ready");
            abort_cycle(QStringLiteral("sensor failure"));
            return;
        }

        const double value = sensor->read();
        if (!std::isfinite(value) || value < 0.0) {
            qDebug().noquote() << sensor->name() + QStringLiteral(": invalid reading");
            abort_cycle(QStringLiteral("sensor failure"));
            return;
        }
        qDebug().noquote() << format_reading(*sensor, value);
    }
    qDebug().noquote() << QStringLiteral("All sensors are ready");

    if (navigation_ == nullptr || !navigation_->is_valid()) {
        qDebug().noquote() << QStringLiteral("Navigation data invalid");
        return;
    }
    const Position position = navigation_->get_position();
    if (!valid_position(position)) {
        qDebug().noquote() << QStringLiteral("Error: invalid navigation position");
        return;
    }
    if (controller_ == nullptr) {
        qDebug().noquote() << QStringLiteral("Error: flight controller is not set");
        return;
    }

    const double error = target_altitude - position.altitude;
    const double output = controller_->calculate_control(error, control_step);
    if (!std::isfinite(output)) {
        qDebug().noquote() << QStringLiteral("Error: invalid controller output");
        return;
    }

    qDebug().noquote() << QStringLiteral("Navigation:") << navigation_->system_name();
    qDebug().noquote() << QStringLiteral("Current altitude:") << position.altitude << QStringLiteral("m");
    qDebug().noquote() << QStringLiteral("Target altitude:") << target_altitude << QStringLiteral("m");
    qDebug().noquote() << QStringLiteral("Altitude error:") << error << QStringLiteral("m");
    qDebug().noquote() << QStringLiteral("Controller output:") << output;
    qDebug().noquote() << QStringLiteral("Autopilot cycle completed");
}
