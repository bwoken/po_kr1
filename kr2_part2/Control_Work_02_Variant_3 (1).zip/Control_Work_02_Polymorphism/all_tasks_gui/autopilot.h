#pragma once

#include <vector>

class UAV;
class Sensor;
class NavigationSystem;
class FlightController;

class Autopilot {
public:
    // The caller owns the modules and keeps them alive throughout the cycle.
    Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
              NavigationSystem* navigation, FlightController* controller);
    void run_cycle();

private:
    UAV* vehicle_;
    std::vector<Sensor*> sensors_;
    NavigationSystem* navigation_;
    FlightController* controller_;
};
