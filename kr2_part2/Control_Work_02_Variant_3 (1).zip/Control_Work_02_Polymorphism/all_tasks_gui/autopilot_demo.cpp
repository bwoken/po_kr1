#include "autopilot.h"
#include "controller.h"
#include "autopilot_demo.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"

#include <QDebug>
#include <vector>

namespace {

enum class TestCase {
    Normal,
    SensorNotReady,
    InvalidNavigation,
    MissingController,
    NegativeAltitude,
    MissingVehicle,
    MissingSensor,
    MissingNavigation,
};

void run_case(TestCase test_case)
{
    SurveyUAV survey;
    Lidar lidar;
    Radar radar;
    Camera camera;

    lidar.set_ready(test_case != TestCase::SensorNotReady);
    const double altitude = test_case == TestCase::NegativeAltitude ? -10.0 : 150.0;
    GPSNavigation gps({55.75, 37.61, altitude}, 8, test_case != TestCase::InvalidNavigation);
    SimpleController controller(0.5);
    const std::vector<Sensor*> sensors{
        test_case == TestCase::MissingSensor ? nullptr : &lidar,
        &radar,
        &camera,
    };
    Autopilot autopilot(test_case == TestCase::MissingVehicle ? nullptr : &survey,
                        sensors,
                        test_case == TestCase::MissingNavigation ? nullptr : &gps,
                        test_case == TestCase::MissingController ? nullptr : &controller);
    autopilot.run_cycle();
}

} // namespace

std::vector<Scenario> autopilot_scenarios()
{
    const std::vector<Scenario> required_cases{
        {QStringLiteral("1. Штатный цикл"), [] { run_case(TestCase::Normal); }},
        {QStringLiteral("2. Сенсор не готов"), [] { run_case(TestCase::SensorNotReady); }},
        {QStringLiteral("3. Навигация невалидна"), [] { run_case(TestCase::InvalidNavigation); }},
        {QStringLiteral("4. Контроллер отсутствует"), [] { run_case(TestCase::MissingController); }},
        {QStringLiteral("5. Отрицательная высота"), [] { run_case(TestCase::NegativeAltitude); }},
    };

    std::vector<Scenario> scenarios{
        {QStringLiteral("Все обязательные сценарии"), [required_cases] {
            for (const auto& scenario : required_cases) {
                qDebug().noquote() << scenario.label;
                scenario.run();
                qDebug().noquote() << QString();
            }
        }},
    };
    scenarios.insert(scenarios.end(), required_cases.begin(), required_cases.end());
    scenarios.push_back({QStringLiteral("6. БПЛА отсутствует"), [] { run_case(TestCase::MissingVehicle); }});
    scenarios.push_back({QStringLiteral("7. Сенсор отсутствует"), [] { run_case(TestCase::MissingSensor); }});
    scenarios.push_back({QStringLiteral("8. Навигация отсутствует"), [] { run_case(TestCase::MissingNavigation); }});

    return scenarios;
}
