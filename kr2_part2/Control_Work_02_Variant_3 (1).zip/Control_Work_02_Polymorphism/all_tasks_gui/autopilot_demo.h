#pragma once

#include "demo_window.h"

std::vector<Scenario> autopilot_scenarios();
