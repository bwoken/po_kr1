#include "demo_window.h"

#include <QComboBox>
#include <QFontDatabase>
#include <QHBoxLayout>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QScopeGuard>
#include <QStringList>
#include <QVBoxLayout>
#include <QWidget>

#include <cstdio>
#include <utility>

namespace {

thread_local QStringList* active_log = nullptr;

void write_log(QtMsgType type, const QMessageLogContext& context, const QString& message)
{
    if (active_log != nullptr && type == QtDebugMsg)
        active_log->append(message);

    const QByteArray line = qFormatLogMessage(type, context, message).toLocal8Bit();
    std::fprintf(stderr, "%s\n", line.constData());
    std::fflush(stderr);
}

QString run_with_log(const Scenario& scenario)
{
    QStringList lines;
    active_log = &lines;
    const auto previous_handler = qInstallMessageHandler(write_log);
    const auto restore = qScopeGuard([previous_handler] {
        qInstallMessageHandler(previous_handler);
        active_log = nullptr;
    });

    scenario.run();
    return lines.join(QLatin1Char('\n'));
}

} // namespace

QWidget* create_task_tab(const QString& title, const QString& description,
                         std::vector<Scenario> scenarios)
{
    auto* tab = new QWidget;

    auto* heading = new QLabel(title, tab);
    heading->setObjectName(QStringLiteral("taskTitle"));
    auto* details = new QLabel(description, tab);
    details->setObjectName(QStringLiteral("taskDetails"));
    details->setWordWrap(true);

    auto* selection = new QComboBox(tab);
    selection->setObjectName(QStringLiteral("scenario"));
    for (const auto& scenario : scenarios)
        selection->addItem(scenario.label);

    auto* run_button = new QPushButton(QStringLiteral("Запустить"), tab);
    run_button->setObjectName(QStringLiteral("run"));

    auto* log = new QPlainTextEdit(tab);
    log->setObjectName(QStringLiteral("log"));
    log->setReadOnly(true);
    log->setPlaceholderText(QStringLiteral("Выберите сценарий и нажмите «Запустить»."));
    log->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));

    auto* controls = new QHBoxLayout;
    auto* scenario_label = new QLabel(QStringLiteral("Сценарий"), tab);
    scenario_label->setBuddy(selection);
    controls->setSpacing(12);
    controls->addWidget(scenario_label);
    controls->addWidget(selection, 1);
    controls->addWidget(run_button);

    auto* layout = new QVBoxLayout(tab);
    layout->setContentsMargins(24, 22, 24, 24);
    layout->setSpacing(8);
    layout->addWidget(heading);
    layout->addWidget(details);
    layout->addSpacing(10);
    layout->addLayout(controls);
    layout->addSpacing(10);
    auto* log_label = new QLabel(QStringLiteral("Журнал выполнения"), tab);
    log_label->setObjectName(QStringLiteral("logTitle"));
    layout->addWidget(log_label);
    layout->addWidget(log, 1);

    QObject::connect(run_button, &QPushButton::clicked, tab,
                     [selection, log, scenarios = std::move(scenarios)] {
        const int index = selection->currentIndex();
        if (index >= 0)
            log->setPlainText(run_with_log(scenarios.at(index)));
    });

    return tab;
}
