#pragma once

#include <QString>
#include <functional>
#include <vector>

class QWidget;

struct Scenario {
    QString label;
    std::function<void()> run;
};

QWidget* create_task_tab(const QString& title, const QString& description,
                         std::vector<Scenario> scenarios);
