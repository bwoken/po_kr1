#include "autopilot_demo.h"
#include "controller_demo.h"
#include "demo_window.h"
#include "sensor_demo.h"
#include "uav_demo.h"

#include <QApplication>
#include <QLabel>
#include <QStyleFactory>
#include <QTabWidget>
#include <QVBoxLayout>

namespace {

const char theme[] = R"(
    QWidget { background: #101827; color: #edf3fb; font-size: 14px; }
    QWidget#dashboard { background: #0c1320; }
    QLabel { background: transparent; }
    QLabel#appTitle { font-size: 25px; font-weight: bold; }
    QLabel#appMeta { color: #91aac2; }
    QLabel#taskTitle { font-size: 22px; font-weight: bold; }
    QLabel#taskDetails { color: #afc1d6; }
    QLabel#logTitle { color: #b5c8dc; font-weight: bold; }
    QTabWidget::pane { border: 1px solid #293a52; border-radius: 8px; top: -1px; }
    QTabBar::tab {
        background: #101b2b; color: #b5c8dc; border: 1px solid #293a52;
        border-top-left-radius: 8px; border-top-right-radius: 8px;
        padding: 10px 17px; margin-right: 5px;
    }
    QTabBar::tab:selected { background: #20364e; color: #edfbff; border-bottom: 2px solid #60dbec; }
    QTabBar::tab:hover:!selected { background: #1a2a40; }
    QTabBar::tab:focus { border-top-color: #60dbec; }
    QComboBox {
        background: #17263a; border: 1px solid #39516e; border-radius: 7px;
        padding: 8px 12px; selection-background-color: #244860;
    }
    QComboBox QAbstractItemView { background: #17263a; selection-background-color: #2b4f68; }
    QPushButton {
        background: #63d9e8; color: #0b2532; font-weight: bold;
        border: 2px solid transparent; border-radius: 7px; padding: 7px 20px;
    }
    QPushButton:hover { background: #96e8f2; }
    QPushButton:pressed { background: #48b9cc; }
    QPushButton:focus { border-color: #e7fcff; }
    QComboBox:focus, QPlainTextEdit:focus { border-color: #63d9e8; }
    QPlainTextEdit {
        background: #090f1a; color: #d9e9f8; border: 1px solid #293a52;
        border-radius: 8px; padding: 9px; selection-background-color: #2b4f68;
    }
)";

} // namespace

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    app.setStyle(QStyleFactory::create(QStringLiteral("Fusion")));
    app.setStyleSheet(QString::fromLatin1(theme));

    QWidget window;
    window.setObjectName(QStringLiteral("dashboard"));
    window.setWindowTitle(QStringLiteral("Контрольная работа №2 · Вариант 3"));
    window.resize(880, 590);
    window.setMinimumSize(650, 430);

    auto* heading = new QLabel(QStringLiteral("Системы БПЛА"), &window);
    heading->setObjectName(QStringLiteral("appTitle"));
    auto* meta = new QLabel(QStringLiteral("Контрольная работа №2 · Вариант 3"), &window);
    meta->setObjectName(QStringLiteral("appMeta"));

    auto* tabs = new QTabWidget(&window);
    tabs->addTab(create_task_tab(QStringLiteral("Миссии БПЛА"),
        QStringLiteral("Запустите тестовые миссии трёх типов аппаратов или проверьте ошибку посадки."),
        {
            {QStringLiteral("Три тестовые миссии"), run_missions},
            {QStringLiteral("Ошибка: посадка до взлёта"), land_before_takeoff},
        }), QStringLiteral("1. БПЛА"));

    tabs->addTab(create_task_tab(QStringLiteral("Сенсоры"),
        QStringLiteral("Проверьте показания лидара, радара и камеры при порогах 10 и 20 м."),
        {
            {QStringLiteral("Показания и пороги 10 и 20 м"), run_sensor_demo},
            {QStringLiteral("Ошибка: лидар не готов"), run_sensor_failure},
        }), QStringLiteral("2. Сенсоры"));

    tabs->addTab(create_task_tab(QStringLiteral("Регуляторы полёта"),
        QStringLiteral("Сравните выходы PID, простого и нечёткого регуляторов при одной ошибке."),
        {
            {QStringLiteral("Три регулятора: ошибка 2,5, шаг 0,1 с"), [] { run_controllers(0.1); }},
            {QStringLiteral("Ошибка: нулевой шаг времени"), [] { run_controllers(0.0); }},
        }), QStringLiteral("3. Регуляторы"));

    tabs->addTab(create_task_tab(QStringLiteral("Цикл автопилота"),
        QStringLiteral("Проверьте расчёт управления по высоте и реакцию на ошибки модулей."),
        autopilot_scenarios()), QStringLiteral("4. Автопилот"));

    auto* layout = new QVBoxLayout(&window);
    layout->setContentsMargins(24, 20, 24, 20);
    layout->setSpacing(5);
    layout->addWidget(heading);
    layout->addWidget(meta);
    layout->addSpacing(13);
    layout->addWidget(tabs, 1);

    window.show();
    return app.exec();
}
