#include "navigation.h"

GPSNavigation::GPSNavigation(Position position, int satellites, bool valid)
    : position_(position), satellites_(satellites), valid_(valid)
{
}

Position GPSNavigation::get_position() const { return position_; }
bool GPSNavigation::is_valid() const { return satellites_ >= 4 && valid_; }
QString GPSNavigation::system_name() const { return QStringLiteral("GPS"); }
