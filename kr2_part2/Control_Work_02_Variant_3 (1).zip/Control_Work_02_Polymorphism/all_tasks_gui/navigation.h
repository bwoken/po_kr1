#pragma once

#include <QString>

struct Position {
    double latitude;
    double longitude;
    double altitude;
};

class NavigationSystem {
public:
    virtual Position get_position() const = 0;
    virtual bool is_valid() const = 0;
    virtual QString system_name() const = 0;
    virtual ~NavigationSystem() = default;
};

class GPSNavigation final : public NavigationSystem {
public:
    GPSNavigation(Position position, int satellites, bool valid = true);
    Position get_position() const override;
    bool is_valid() const override;
    QString system_name() const override;

private:
    Position position_;
    int satellites_;
    bool valid_;
};
