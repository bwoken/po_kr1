#include "uav_demo.h"

#include <QDebug>

int main()
{
    run_missions();
    qDebug().noquote() << QStringLiteral("\nError scenario");
    land_before_takeoff();
    return 0;
}
