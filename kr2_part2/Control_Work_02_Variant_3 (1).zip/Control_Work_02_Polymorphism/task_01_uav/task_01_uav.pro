QT = core
TEMPLATE = app
TARGET = task_01_uav
CONFIG += console c++17
CONFIG -= app_bundle
win32-msvc*: QMAKE_CXXFLAGS += /utf-8

SOURCES += main.cpp
include(uav_module.pri)
