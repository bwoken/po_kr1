#include "uav.h"

#include <QDebug>

void UAV::begin_flight(const QString& action)
{
    if (airborne_) {
        qDebug().noquote() << type() + QStringLiteral(": Error: already in flight");
        return;
    }
    airborne_ = true;
    qDebug().noquote() << type() + QStringLiteral(": ") + action;
}

void UAV::end_flight(const QString& action)
{
    if (!airborne_) {
        qDebug().noquote() << type() + QStringLiteral(": Error: landing before takeoff");
        return;
    }
    airborne_ = false;
    qDebug().noquote() << type() + QStringLiteral(": ") + action;
}

void SurveyUAV::takeoff() { begin_flight(QStringLiteral("vertical takeoff")); }
void SurveyUAV::land() { end_flight(QStringLiteral("vertical landing")); }
QString SurveyUAV::type() const { return QStringLiteral("Survey UAV"); }
QString SurveyUAV::mission_type() const { return QStringLiteral("terrain mapping"); }

void CargoUAV::takeoff() { begin_flight(QStringLiteral("takeoff with payload")); }
void CargoUAV::land() { end_flight(QStringLiteral("landing with payload")); }
QString CargoUAV::type() const { return QStringLiteral("Cargo UAV"); }
QString CargoUAV::mission_type() const { return QStringLiteral("payload transportation"); }

void ReconnaissanceUAV::takeoff() { begin_flight(QStringLiteral("runway takeoff")); }
void ReconnaissanceUAV::land() { end_flight(QStringLiteral("gliding landing")); }
QString ReconnaissanceUAV::type() const { return QStringLiteral("Reconnaissance UAV"); }
QString ReconnaissanceUAV::mission_type() const
{
    return QStringLiteral("observation and monitoring");
}

void execute_test_mission(UAV& vehicle)
{
    qDebug().noquote() << vehicle.type() + QStringLiteral(": ") + vehicle.mission_type();
    vehicle.takeoff();
    vehicle.land();
    qDebug().noquote() << QStringLiteral("Test mission completed");
}
