#pragma once

#include <QString>

class UAV {
public:
    virtual void takeoff() = 0;
    virtual void land() = 0;
    virtual QString type() const = 0;
    virtual QString mission_type() const = 0;
    virtual ~UAV() = default;

protected:
    void begin_flight(const QString& action);
    void end_flight(const QString& action);

private:
    bool airborne_ = false;
};

class SurveyUAV final : public UAV {
public:
    void takeoff() override;
    void land() override;
    QString type() const override;
    QString mission_type() const override;
};

class CargoUAV final : public UAV {
public:
    void takeoff() override;
    void land() override;
    QString type() const override;
    QString mission_type() const override;
};

class ReconnaissanceUAV final : public UAV {
public:
    void takeoff() override;
    void land() override;
    QString type() const override;
    QString mission_type() const override;
};

void execute_test_mission(UAV& vehicle);
