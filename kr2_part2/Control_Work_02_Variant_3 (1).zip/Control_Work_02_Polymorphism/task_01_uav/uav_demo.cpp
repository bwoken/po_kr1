#include "uav_demo.h"

#include "uav.h"

void run_missions()
{
    SurveyUAV survey;
    CargoUAV cargo;
    ReconnaissanceUAV reconnaissance;
    UAV* const vehicles[] = {&survey, &cargo, &reconnaissance};

    for (UAV* vehicle : vehicles)
        execute_test_mission(*vehicle);
}

void land_before_takeoff()
{
    SurveyUAV survey;
    UAV& vehicle = survey;
    vehicle.land();
}
