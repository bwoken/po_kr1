#pragma once

void run_missions();
void land_before_takeoff();
