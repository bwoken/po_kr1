INCLUDEPATH += $$PWD
SOURCES += $$PWD/uav.cpp $$PWD/uav_demo.cpp
HEADERS += $$PWD/uav.h $$PWD/uav_demo.h
