#include "sensor_demo.h"

#include <QDebug>

int main()
{
    run_sensor_demo();
    qDebug().noquote() << QStringLiteral("\nError scenario");
    run_sensor_failure();
    return 0;
}
