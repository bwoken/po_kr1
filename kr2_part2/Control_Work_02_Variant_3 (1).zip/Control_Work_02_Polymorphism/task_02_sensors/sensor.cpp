#include "sensor.h"

#include <QDebug>
#include <cmath>

Lidar::Lidar(double distance) : distance_(distance) {}
double Lidar::read() { return distance_; }
bool Lidar::is_ready() const { return ready_; }
QString Lidar::name() const { return QStringLiteral("Lidar"); }
QString Lidar::reading_label() const { return QStringLiteral("nearest obstacle"); }
bool Lidar::measures_distance() const { return true; }
void Lidar::set_ready(bool ready) { ready_ = ready; }

Radar::Radar(double distance) : distance_(distance) {}
double Radar::read() { return distance_; }
bool Radar::is_ready() const { return true; }
QString Radar::name() const { return QStringLiteral("Radar"); }
QString Radar::reading_label() const { return QStringLiteral("nearest object"); }
bool Radar::measures_distance() const { return true; }

Camera::Camera(int count) : count_(count) {}
double Camera::read() { return count_; }
bool Camera::is_ready() const { return true; }
QString Camera::name() const { return QStringLiteral("Camera"); }
QString Camera::reading_label() const { return QStringLiteral("detected objects"); }
bool Camera::measures_distance() const { return false; }

QString format_reading(const Sensor& sensor, double value)
{
    const auto unit = sensor.measures_distance() ? QStringLiteral(" m") : QString();
    return QStringLiteral("%1: %2=%3%4")
        .arg(sensor.name(), sensor.reading_label(), QString::number(value), unit);
}

bool obstacle_is_near(Sensor& sensor, double threshold)
{
    if (!std::isfinite(threshold) || threshold <= 0.0) {
        qDebug().noquote() << QStringLiteral("Error: invalid distance threshold");
        return false;
    }
    if (!sensor.is_ready()) {
        qDebug().noquote() << sensor.name() + QStringLiteral(": sensor is not ready");
        return false;
    }
    if (!sensor.measures_distance())
        return false;

    const double distance = sensor.read();
    if (!std::isfinite(distance) || distance < 0.0) {
        qDebug().noquote() << sensor.name() + QStringLiteral(": invalid distance");
        return false;
    }
    return distance < threshold;
}
