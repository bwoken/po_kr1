#pragma once

#include <QString>

class Sensor {
public:
    virtual double read() = 0;
    virtual bool is_ready() const = 0;
    virtual QString name() const = 0;
    virtual QString reading_label() const = 0;
    virtual bool measures_distance() const = 0;
    virtual ~Sensor() = default;
};

class Lidar final : public Sensor {
public:
    explicit Lidar(double distance = 12.5);
    double read() override;
    bool is_ready() const override;
    QString name() const override;
    QString reading_label() const override;
    bool measures_distance() const override;
    void set_ready(bool ready);

private:
    double distance_;
    bool ready_ = true;
};

class Radar final : public Sensor {
public:
    explicit Radar(double distance = 18.2);
    double read() override;
    bool is_ready() const override;
    QString name() const override;
    QString reading_label() const override;
    bool measures_distance() const override;

private:
    double distance_;
};

class Camera final : public Sensor {
public:
    explicit Camera(int count = 3);
    double read() override;
    bool is_ready() const override;
    QString name() const override;
    QString reading_label() const override;
    bool measures_distance() const override;

private:
    int count_;
};

QString format_reading(const Sensor& sensor, double value);
bool obstacle_is_near(Sensor& sensor, double threshold);
