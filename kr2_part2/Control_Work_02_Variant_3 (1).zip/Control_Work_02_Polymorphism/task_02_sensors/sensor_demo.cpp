#include "sensor_demo.h"

#include "sensor.h"

#include <QDebug>
#include <vector>

void run_sensor_demo()
{
    Lidar lidar;
    Radar radar;
    Camera camera;
    const std::vector<Sensor*> sensors{&lidar, &radar, &camera};

    for (Sensor* sensor : sensors)
        qDebug().noquote() << format_reading(*sensor, sensor->read());

    for (const double threshold : {10.0, 20.0}) {
        qDebug().noquote() << QString();
        qDebug().noquote() << QStringLiteral("Threshold:") << threshold << QStringLiteral("m");
        for (Sensor* sensor : sensors) {
            const bool is_near = obstacle_is_near(*sensor, threshold);
            const auto result = is_near ? QStringLiteral("true") : QStringLiteral("false");
            const auto explanation = sensor->measures_distance()
                ? QString() : QStringLiteral(" (distance unavailable)");
            qDebug().noquote() << sensor->name() + QStringLiteral(": ") + result + explanation;
        }
    }
}

void run_sensor_failure()
{
    Lidar lidar;
    lidar.set_ready(false);
    const bool is_near = obstacle_is_near(lidar, 20.0);
    qDebug().noquote() << QStringLiteral("obstacle_is_near: %1")
        .arg(is_near ? QStringLiteral("true") : QStringLiteral("false"));
}
