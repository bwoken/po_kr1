#pragma once

void run_sensor_demo();
void run_sensor_failure();
