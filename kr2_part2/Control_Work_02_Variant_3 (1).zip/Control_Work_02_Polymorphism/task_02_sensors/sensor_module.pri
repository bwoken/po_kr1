INCLUDEPATH += $$PWD
SOURCES += $$PWD/sensor.cpp $$PWD/sensor_demo.cpp
HEADERS += $$PWD/sensor.h $$PWD/sensor_demo.h
