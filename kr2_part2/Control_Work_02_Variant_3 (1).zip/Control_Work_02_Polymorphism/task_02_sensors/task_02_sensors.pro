QT = core
TEMPLATE = app
TARGET = task_02_sensors
CONFIG += console c++17
CONFIG -= app_bundle
win32-msvc*: QMAKE_CXXFLAGS += /utf-8

SOURCES += main.cpp
include(sensor_module.pri)
