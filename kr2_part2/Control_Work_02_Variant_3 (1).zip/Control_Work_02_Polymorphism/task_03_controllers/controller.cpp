#include "controller.h"

#include <QDebug>
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace {

bool valid_input(double error, double dt)
{
    return std::isfinite(error) && std::isfinite(dt) && dt > 0.0;
}

} // namespace

PIDController::PIDController(double kp, double ki, double kd)
    : kp_(kp), ki_(ki), kd_(kd)
{
}

double PIDController::calculate_control(double error, double dt)
{
    if (!valid_input(error, dt))
        return std::numeric_limits<double>::quiet_NaN();

    const double next_integral = integral_ + error * dt;
    const double derivative = (error - previous_error_) / dt;
    const double output = kp_ * error + ki_ * next_integral + kd_ * derivative;

    if (!std::isfinite(output))
        return std::numeric_limits<double>::quiet_NaN();

    integral_ = next_integral;
    previous_error_ = error;
    return output;
}

QString PIDController::controller_name() const { return QStringLiteral("PID"); }

SimpleController::SimpleController(double coefficient) : coefficient_(coefficient) {}

double SimpleController::calculate_control(double error, double dt)
{
    if (!valid_input(error, dt))
        return std::numeric_limits<double>::quiet_NaN();
    return coefficient_ * error;
}

QString SimpleController::controller_name() const { return QStringLiteral("Simple"); }

double FuzzyController::calculate_control(double error, double dt)
{
    if (!valid_input(error, dt))
        return std::numeric_limits<double>::quiet_NaN();

    // Five overlapping triangular sets, with saturation at the outer sets.
    constexpr std::array<double, 5> centers{-10.0, -5.0, 0.0, 5.0, 10.0};
    constexpr std::array<double, 5> rule_outputs{-8.0, -3.0, 0.0, 3.0, 8.0};
    constexpr double half_width = 5.0;
    const double input = std::clamp(error, centers.front(), centers.back());

    double weighted_output = 0.0;
    double total_weight = 0.0;
    for (std::size_t i = 0; i < centers.size(); ++i) {
        const double weight = std::max(0.0, 1.0 - std::abs(input - centers[i]) / half_width);
        weighted_output += weight * rule_outputs[i];
        total_weight += weight;
    }
    return weighted_output / total_weight;
}

QString FuzzyController::controller_name() const { return QStringLiteral("Fuzzy"); }

void test_controller(FlightController& controller, double error, double dt)
{
    qDebug().noquote() << QStringLiteral("Controller:") << controller.controller_name();
    qDebug().noquote() << QStringLiteral("Error:") << error;
    qDebug().noquote() << QStringLiteral("dt:") << dt << QStringLiteral("s");

    const double output = controller.calculate_control(error, dt);
    if (std::isfinite(output)) {
        qDebug().noquote() << QStringLiteral("Control output:") << output;
    } else if (!valid_input(error, dt)) {
        qDebug().noquote() << QStringLiteral("Error: invalid controller input (dt must be positive)");
    } else {
        qDebug().noquote() << QStringLiteral("Error: invalid controller output");
    }
}
