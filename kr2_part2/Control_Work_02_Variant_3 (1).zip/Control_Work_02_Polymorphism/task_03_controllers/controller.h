#pragma once

#include <QString>

class FlightController {
public:
    virtual double calculate_control(double error, double dt) = 0;
    virtual QString controller_name() const = 0;
    virtual ~FlightController() = default;
};

class PIDController final : public FlightController {
public:
    PIDController(double kp, double ki, double kd);
    double calculate_control(double error, double dt) override;
    QString controller_name() const override;

private:
    double kp_;
    double ki_;
    double kd_;
    double integral_ = 0.0;
    double previous_error_ = 0.0;
};

class SimpleController final : public FlightController {
public:
    explicit SimpleController(double coefficient);
    double calculate_control(double error, double dt) override;
    QString controller_name() const override;

private:
    double coefficient_;
};

class FuzzyController final : public FlightController {
public:
    double calculate_control(double error, double dt) override;
    QString controller_name() const override;
};

void test_controller(FlightController& controller, double error, double dt);
