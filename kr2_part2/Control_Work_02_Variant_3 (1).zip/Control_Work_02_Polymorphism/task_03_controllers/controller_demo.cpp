#include "controller_demo.h"

#include "controller.h"

#include <QDebug>

void run_controllers(double dt)
{
    PIDController pid(0.5, 0.48, 0.02);
    SimpleController simple(0.5);
    FuzzyController fuzzy;
    FlightController* const controllers[] = {&pid, &simple, &fuzzy};

    for (auto* controller : controllers) {
        test_controller(*controller, 2.5, dt);
        qDebug().noquote() << QString();
    }
}
