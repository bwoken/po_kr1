INCLUDEPATH += $$PWD
SOURCES += $$PWD/controller.cpp $$PWD/controller_demo.cpp
HEADERS += $$PWD/controller.h $$PWD/controller_demo.h
