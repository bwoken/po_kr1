#include "controller_demo.h"

#include <QDebug>

int main()
{
    run_controllers(0.1);
    qDebug().noquote() << QStringLiteral("\nError scenario");
    run_controllers(0.0);
    return 0;
}
